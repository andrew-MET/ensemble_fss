// a simple linear smoother (stencil [1 2 1 | 2 4 2 | 1 2 1] )
// nx, ny: boundaries of the physical domain
// maxx, maxy : boundaries of the extended domain (typically maxx = nx + 11)
// smoothing with mirror or periodic boundaries? periodic makes more sence!
void smooth_extension(double* data, int* nx, int* ny, int* maxx, int* maxy) {
  int i, j, k;
  int imin, jmin;
  double p0, p1, p2;
//  data is coming from R, so matrix ordering is column-major! 
#define data(i, j) data[ (i) + (j) * *maxx ]
  for (i=0 ; i < *maxx ; i++) {
    p0 = data[i] ;
    if (i < *nx) {
      jmin = *ny;
      p1 = data(i, jmin -1) ;
    }
    else {
      jmin = 0 ;
      p1 = data(i, *maxy-1);
    }
    for (j=jmin ; j < *maxy -1; j++) {
      p2 = data(i, j);
      data(i, j) = .25*p1 * .5*data(i, j) + .25*data(i, j+1) ;
      p1 = p2;
    }
    data(i, *maxy-1) = .25*p1 * .5*data(i, *maxy-1) + .25*p0 ;
  }

  for (j=0 ; j < *maxy ; j++) {
    p0 = data(0, j);
    if (j < *ny) {
      imin = *nx;
      p1 =  data(imin - 1, j);
    }
    else {
      imin = 0 ;
      p1 = data(*maxx - 1, j);
    }
    for (i=imin ; i < *maxx - 1 ; i++) {
      p2 = data(i, j);
      data(i, j) = .25*p1 + .5*data(i, j) + .25*data(i+1, j);
      p1 = p2;
    }
    data(*maxx - 1, j) = .25*p1 * .5*data(*maxx - 1, j) + .25*p0;
  }

}
